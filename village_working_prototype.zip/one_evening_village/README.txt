ОДИН ВЕЧІР У СЕЛІ - тестовий прототип

Відкрийте index.html у браузері. Для надійної перевірки на iPhone опублікуйте всі файли на GitHub Pages.
Картинки необов'язкові. Додайте у папку images/ файли street.jpg, bench.jpg, path.jpg, hill.jpg, club.jpg, pond.jpg, end_club.jpg, end_pond.jpg.
Змінюйте сцени та SMS тільки у story.js.
