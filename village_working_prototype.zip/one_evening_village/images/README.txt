Сюди покладіть зображення: street.jpg, bench.jpg, path.jpg, hill.jpg, club.jpg, pond.jpg, end_club.jpg, end_pond.jpg.
Якщо їх немає, гра показує сірі заглушки з назвами файлів.
Рекомендований формат 4:5 (наприклад 1200x1500), JPG або WebP.
